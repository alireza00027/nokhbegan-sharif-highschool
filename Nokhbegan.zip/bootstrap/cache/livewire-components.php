<?php return array (
  'exams.analysis-point' => 'App\\Http\\Livewire\\Exams\\AnalysisPoint',
  'exams.create-exam' => 'App\\Http\\Livewire\\Exams\\CreateExam',
  'exams.filter-exams' => 'App\\Http\\Livewire\\Exams\\FilterExams',
  'users.select-students' => 'App\\Http\\Livewire\\Users\\SelectStudents',
);