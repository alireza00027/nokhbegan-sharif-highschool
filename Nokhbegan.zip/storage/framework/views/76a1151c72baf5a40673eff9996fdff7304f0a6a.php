
<?php $__env->startSection('style'); ?>
    <!-- Persian Data Picker -->
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/persian-datepicker.min.css')); ?>">
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">
    <!-- iCheck for checkboxes and radio inputs -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/iCheck/all.css')); ?>">
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/select2/select2.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/admin/exams/exams.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('exams.create-exam', [])->html();
} elseif ($_instance->childHasBeenRendered('3e0gdQ6')) {
    $componentId = $_instance->getRenderedChildComponentId('3e0gdQ6');
    $componentTag = $_instance->getRenderedChildComponentTagName('3e0gdQ6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3e0gdQ6');
} else {
    $response = \Livewire\Livewire::mount('exams.create-exam', []);
    $html = $response->html();
    $_instance->logRenderedChild('3e0gdQ6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <!-- Persian Data Picker -->
    <script src="<?php echo e(asset('js/persian-date.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/persian-datepicker.min.js')); ?>"></script>
    <!-- DataTables -->
    <script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.js')); ?>"></script>
    <!-- iCheck -->
    <script src="<?php echo e(asset('plugins/iCheck/icheck.min.js')); ?>"></script>
    <!-- Select2 -->
    <script src="<?php echo e(asset('plugins/select2/select2.full.min.js')); ?>"></script>
    <!-- Page script -->
    <script src="<?php echo e(asset('js/admin/exams/exam.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => $title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Nokhbegan\resources\views/admin/exams/create.blade.php ENDPATH**/ ?>