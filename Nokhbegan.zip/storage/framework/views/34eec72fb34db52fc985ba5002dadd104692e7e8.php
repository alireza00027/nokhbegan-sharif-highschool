
<?php $__env->startSection('style'); ?>
    <!-- Persian Data Picker -->
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/persian-datepicker.min.css')); ?>">
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">
    <!-- iCheck for checkboxes and radio inputs -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/iCheck/all.css')); ?>">
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/select2/select2.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/admin/exams/exams.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
    <!-- Main content -->
    <section class="content pt-3">
        <div class="row">
            <div class="col-12">
                <div class="card card-nokhbegan">
                    <div class="card-header">
                        <h3 class="card-title">برنامه هفتگی هفته <?php echo e($schedule->getNumberWeek()); ?> ماه <?php echo e($schedule->month); ?></h3>
                    </div>
                    <!-- /.card-header -->
                    
                        <form action="<?php echo e(route('schedules.process',['schedule'=>$schedule->id])); ?>" method="post" class="form-control">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PATCH')); ?>

                            <div class="card-body ">
                                <?php echo $__env->make('layouts.sections.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <hr class="w-100 m-0">
                        <div class="d-flex flex-column flex-sm-row align-items-center align-items-sm-start mx-sm-3 mt-4">

                            <div class="mr-sm-5 mt-4 mt-sm-0">
                                <div class="mt-3 mt-sm-2">
                                    <label for="month" class="width120">ماه: </label>
                                    <span id="month"><?php echo e($schedule->month); ?></span>
                                </div>
                                <div class="mt-3 mt-sm-2">
                                    <label for="day_of_week" class="width120">هفته: </label>
                                    <span id="day_of_week"><?php echo e($schedule->getNumberWeek()); ?></span>
                                </div>
                                <div class="mt-3 mt-sm-2">
                                    <label for="sum_hour_request" class="width120">مجموع زمان در نظر گرفته شده : </label>
                                    <span id="sum_hour_request" class="text-danger"><?php echo e($schedule->sum_hour_request); ?> دقیقه</span>
                                </div>
                                <div class="mt-3 mt-sm-2">
                                    <label for="sum_hour_answer" class="width120">مجموع زمان پاسخ داده شده: </label>
                                    <span id="sum_hour_answer" class="text-success"><?php echo e($schedule->sum_hour_answer==null ? 0 : $schedule->sum_hour_answer); ?> دقیقه</span>
                                </div>
                            </div>
                        </div>
                                <div class="row mt-3">
                                    <div class="card card-nokhbegan">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-12">
                                                    <table class="table table-responsive">
                                                        <thead>
                                                            <tr class="bg-info">
                                                                <th>روز ها</th>
                                                                <th>دروس امروز</th>
                                                                <th>دروس فردا</th>
                                                                <th>مرور دروس قبل</th>
                                                                <th>تکالیف</th>
                                                                
                                                                <th>مجموع ساعت</th>
                                                                <th>توضیحات</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $answerScheduleItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <th class="text-bold"><?php echo e($value->getDayOfWeekText()); ?></th>
                                                                    <td>
                                                                        <input name="request_amount_today_lessons_<?php echo e($requestScheduleItems[$key]->day_of_week); ?>" id="request_amount_today_lessons" class="form-control text-center text-danger bg-secondary" disabled value="<?php echo e($requestScheduleItems[$key]->amount_today_lessons); ?>">
                                                                        <input name="answer_amount_today_lessons_<?php echo e($value->day_of_week); ?>" id="answer_amount_today_lessons" class="form-control  text-center " <?php if($value->day_of_week != $todayName and $value->created_at != $today): ?> disabled <?php endif; ?>  value="<?php echo e($value->amount_today_lessons); ?>">
                                                                    </td>
                                                                    <td>
                                                                        <input name="request_amount_tomorow_lessons_<?php echo e($requestScheduleItems[$key]->day_of_week); ?>" id="request_amount_tomorow_lessons" class="form-control text-danger text-center bg-secondary" disabled value="<?php echo e($requestScheduleItems[$key]->amount_tomorow_lessons); ?>">
                                                                        <input name="answer_amount_tomorow_lessons_<?php echo e($value->day_of_week); ?>" id="answer_amount_tomorow_lessons" class="form-control  text-center " <?php if($value->day_of_week != $todayName and $value->created_at != $today): ?> disabled <?php endif; ?>   value="<?php echo e($value->amount_tomorow_lessons); ?>">
                                                                    </td>
                                                                    <td>
                                                                        <input name="request_amount_review_previous_lessons_<?php echo e($requestScheduleItems[$key]->day_of_week); ?>" id="request_amount_review_previous_lessons" class="form-control text-center text-danger bg-secondary" disabled value="<?php echo e($requestScheduleItems[$key]->amount_review_previous_lessons); ?>">
                                                                        <input name="answer_amount_review_previous_lessons_<?php echo e($value->day_of_week); ?>" id="answer_amount_review_previous_lessons" class="form-control  text-center " <?php if($value->day_of_week != $todayName and $value->created_at != $today): ?> disabled <?php endif; ?>   value="<?php echo e($value->amount_review_previous_lessons); ?>">
                                                                    </td>
                                                                    <td>
                                                                        <input name="request_home_work_<?php echo e($requestScheduleItems[$key]->day_of_week); ?>" id="request_home_work" class="form-control text-center bg-secondary text-danger" disabled value="<?php echo e($requestScheduleItems[$key]->home_work); ?>">
                                                                        <input name="answer_home_work_<?php echo e($value->day_of_week); ?>" id="answer_home_work" class="form-control  text-center " <?php if($value->day_of_week != $todayName and $value->created_at != $today): ?> disabled <?php endif; ?>  value="<?php echo e($value->home_work); ?>">
                                                                    </td>
                                                                    
                                                                    <td>
                                                                        <div class="d-flex flex-column mr-4">
                                                                            <span class="text-danger"><?php echo e($requestScheduleItems[$key]->sum_hour == null ? 0 : $requestScheduleItems[$key]->sum_hour); ?> دقیقه</span>
                                                                            <span class="text-success mt-3"><?php echo e($value->sum_hour == null ? 0 : $value->sum_hour); ?> دقیقه</span>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <button type="button" data-modaldata="<?php echo e(json_encode($requestScheduleItems[$key])); ?>"class="btn btn-sm btn-outline-nokhbegan btn-open-description-modal mr-2" data-toggle="modal" data-target="#descriptionScheduleItem">
                                                                            توضیحات</i>
                                                                        </button>
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
        
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <button class="btn btn-nokhbegan" type="submit">ویرایش</button>
                            </div>
                        </form>
                    
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<div class="modal fade" id="descriptionScheduleItem" tabindex="-1" role="dialog" aria-labelledby="descriptionScheduleItem" aria-hidden="true">
    <div class="modal-dialog modal-lg animation" role="document">
        <div class="modal-content">
            <div class="modal-header d-flex flex-row align-items-center justify-content-between">
                <h5 class="modal-title">جزئیات</h5>
            </div>
            <div class="modal-body d-flex flex-column centered">
                <div class="w-100 d-flex flex-wrap mt-3 mb-4">
                    <div class="w-100">
                        <div class="row">
                            <div class="col-12">
                                <textarea name="modal-description" id="modal-description" cols="30" rows="10" class="form-control" disabled></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer d-flex align-items-center justify-content-between">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">بستن</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <!-- Persian Data Picker -->
    <script src="<?php echo e(asset('js/persian-date.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/persian-datepicker.min.js')); ?>"></script>
    <!-- DataTables -->
    <script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.js')); ?>"></script>
    <!-- iCheck -->
    <script src="<?php echo e(asset('plugins/iCheck/icheck.min.js')); ?>"></script>
    <!-- Select2 -->
    <script src="<?php echo e(asset('plugins/select2/select2.full.min.js')); ?>"></script>
    <!-- Page script -->
    <script src="<?php echo e(asset('js/admin/exams/exam.js')); ?>"></script>

    <script>
        $('.btn-open-description-modal').click(function () {
            let formData = $(this).data('modaldata');
            $('#modal-description').val(formData.description);
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => $title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Nokhbegan\resources\views/app/schedules/show.blade.php ENDPATH**/ ?>