
<?php $__env->startSection('style'); ?>
    <!-- Persian Data Picker -->
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/persian-datepicker.min.css')); ?>">
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">
    <!-- iCheck for checkboxes and radio inputs -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/iCheck/all.css')); ?>">
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/select2/select2.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/admin/exams/exams.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Main content -->
        <section class="content pt-3">
            <div>
                <div class="card card-nokhbegan">
                    <div class="card-header">
                        <i class="fa fa-arrow-left ml-1"></i>
                        <span class="fs4 font-weight-bold">انتخاب جزئیات</span>
                    </div>
                    <form action="<?php echo e(route('admin.schedules.index')); ?>" class="card-body">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('users.select-students', [])->html();
} elseif ($_instance->childHasBeenRendered('3EbJ6eM')) {
    $componentId = $_instance->getRenderedChildComponentId('3EbJ6eM');
    $componentTag = $_instance->getRenderedChildComponentTagName('3EbJ6eM');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3EbJ6eM');
} else {
    $response = \Livewire\Livewire::mount('users.select-students', []);
    $html = $response->html();
    $_instance->logRenderedChild('3EbJ6eM', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        <div class="row">
                            <div class="form-group col-sm-6 col-md-6">
                                <label for="fromDate">از تاریخ</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                  <span class="input-group-text">
                                    <i class="fa fa-calendar"></i>
                                  </span>
                                    </div>
                                    <input id="fromDate" name="fromDate" value="<?php echo e(request('fromDate')); ?>" class="fromDate form-control"/>
                                    <input id="altFromDate" name="fromDateTimestamp" type="hidden">
                                </div>
                            </div>
                            <div class="form-group col-sm-6 col-md-6">
                                <label for="toDate">تا تاریخ</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                  <span class="input-group-text">
                                    <i class="fa fa-calendar"></i>
                                  </span>
                                    </div>
                                    <input id="toDate" name="toDate" value="<?php echo e(request('toDate')); ?>" class="toDate form-control"/>
                                    <input id="altToDate" name="toDateTimestamp" type="hidden">
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="col-12 btn btn-nokhbegan mr-auto ml-2 mt-3 searchBtn">
                            پردازش
                        </button>
                    </form>
                </div>
                <div>
                    <div class="card card-nokhbegan card-outline pb-3">
                        <div class="w-100 border-bottom-0 pt-3 pb-2 px-3 d-flex flex-column flex-sm-row align-items-center justify-content-between">
                            <h3 class="card-title">لیست آزمون ها</h3>
                            <!-- /.card-tools -->
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body p-0 table-responsive">
                            <table id="usersLists" class="table table-hover text-center"
                                   style="border-spacing: 0; border-collapse: separate;">
                                <thead>
                                <tr>
                                    <th>ردیف</th>
                                    <th>نام دانش آموز</th>
                                    <th>پایه تحصیلی</th>
                                    <th>ماه</th>
                                    <th>شماره هفته</th>
                                    <th>تاریخ</th>
                                    <th>مجموع ساعت درخواست شده</th>
                                    <th>مجموع ساعت پاسخ داده شده</th>
                                    <th>عملیات</th>
                                    
                                </tr>
                                </thead>
                                <tbody>
                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr >
                                                <td><?php echo e($schedule->id); ?></td>
                                                <td><?php echo e($schedule->user->name); ?></td>
                                                <td><?php echo e($schedule->user->grade); ?></td>
                                                <td><?php echo e($schedule->month); ?></td>
                                                <td><?php echo e($schedule->getNumberWeek()); ?></td>
                                                <td><?php echo e($schedule->getTime()); ?></td>
                                                <td><?php echo e($schedule->sum_hour_request); ?></td>
                                                <td><?php echo e($schedule->sum_hour_answer); ?></td>
                                                <td>
                                                    <form action="<?php echo e(route('admin.schedules.destroy',['schedule'=>$schedule->id])); ?>" method="POST">
                                                        <?php echo e(csrf_field()); ?>

                                                        <?php echo e(method_field('DELETE')); ?>

                                                        <div class="btn-group">
                                                            <a href="<?php echo e(route('admin.schedules.show',['schedule'=>$schedule->id])); ?>" class="btn btn-sm btn-outline-primary">مشاهده</a>
                                                            <button type="submit" class="btn btn-sm btn-outline-danger">حذف</button>
                                                        </div>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            
                        </div>
                    </div>
                    <!-- /. box -->
                </div>
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <!-- Persian Data Picker -->
    <script src="<?php echo e(asset('js/persian-date.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/persian-datepicker.min.js')); ?>"></script>
    <!-- DataTables -->
    <script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.js')); ?>"></script>
    <!-- iCheck -->
    <script src="<?php echo e(asset('plugins/iCheck/icheck.min.js')); ?>"></script>
    <!-- Select2 -->
    <script src="<?php echo e(asset('plugins/select2/select2.full.min.js')); ?>"></script>
    <!-- Page script -->
    <script src="<?php echo e(asset('js/admin/exams/exam.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => $title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Nokhbegan\resources\views/admin/schedules/index.blade.php ENDPATH**/ ?>