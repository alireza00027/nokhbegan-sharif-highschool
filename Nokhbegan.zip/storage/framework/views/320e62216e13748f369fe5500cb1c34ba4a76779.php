<!DOCTYPE html>
<html lang="fa">
<head>
    <title>ورود به سیستم</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/index.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom-style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/auth/login.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/adminlte.css')); ?>">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-rtl.min.css')); ?>">
</head>
<body>
<?php echo $__env->yieldContent('content'); ?>
<script src="<?php echo e(asset('js/auth/auth.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/formValidationBootstrap.js')); ?>"></script>
</body>

</html>




<?php /**PATH C:\xampp\htdocs\Nokhbegan\resources\views/layouts/auth.blade.php ENDPATH**/ ?>