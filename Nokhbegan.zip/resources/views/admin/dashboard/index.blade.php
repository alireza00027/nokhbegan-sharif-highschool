@extends('layouts.app', ['title' => $title])
@section('style')
@endsection
@section('content')

@endsection
@section('script')

@endsection